"""Offline self-tests: python3 -m unittest discover -s tests -v"""
from pathlib import Path
import tempfile
import json
import hashlib
import unittest
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from smoke_fixture import (
    initialize, check, audit, PROFILE_PATH, PROFILE_APPROVED_MARKER,
    APPROVED_OUTPUT, APPROVED_MARKER, FIXTURES, MANIFEST_PATH,
    SCHEMA_VERSION, migrate, LEGACY_TO_CURRENT, BACKUP_MANIFEST_PATH,
)


class FixtureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "career-test"
        self.root.mkdir()
        initialize(self.root)

    def test_fresh_baseline_passes(self):
        self.assertEqual(check(self.root, "baseline"), [])
        self.assertEqual(check(self.root, "read"), [])
        self.assertEqual(check(self.root, "app-reject"), [])

    def test_prevents_overwrite(self):
        with self.assertRaises(FileExistsError):
            initialize(self.root)

    def test_unauthorized_profile_mutation_fails(self):
        p = self.root / PROFILE_PATH
        p.write_text(p.read_text() + "\nBAD_CHANGE\n")
        self.assertTrue(check(self.root, "orchestrator-profile-deny"))

    def test_approved_application_marker_required(self):
        self.assertTrue(check(self.root, "app-approve"))
        p = self.root / APPROVED_OUTPUT
        p.write_text(f"{APPROVED_MARKER}\n")
        self.assertEqual(check(self.root, "app-approve"), [])

    def test_profile_approval_requires_specific_marker(self):
        (self.root / APPROVED_OUTPUT).write_text(APPROVED_MARKER + "\n")
        self.assertTrue(check(self.root, "profile-approve"))
        p = self.root / PROFILE_PATH
        p.write_text(p.read_text() + "\n" + PROFILE_APPROVED_MARKER + "\n")
        self.assertEqual(check(self.root, "profile-approve"), [])

    def test_candidate_new_file_fails(self):
        (self.root / "candidate" / "UNEXPECTED.md").write_text("bad")
        self.assertTrue(check(self.root, "read"))

    def test_immutable_draft_change_fails(self):
        p = self.root / "applications/smoke-test/SMOKE_DRAFT.md"
        p.write_text(p.read_text() + "\nchanged\n")
        self.assertTrue(check(self.root, "reviewer-deny"))

    def test_audit_returns_expected_fields(self):
        state = audit(self.root)
        self.assertFalse(state["changed"])
        self.assertFalse(state["approved_output_exists"])


    def test_new_layout_separates_candidate_history_from_target_job(self):
        self.assertTrue((self.root / "candidate/profile/jobs/SMOKE_EMPLOYMENT.md").is_file())
        self.assertTrue((self.root / "candidate/evidence/SMOKE_EVIDENCE_INDEX.md").is_file())
        self.assertTrue((self.root / "candidate/development/SMOKE_FUP.md").is_file())
        self.assertTrue((self.root / "applications/smoke-test/SMOKE_JOB_DESCRIPTION.md").is_file())
        self.assertFalse((self.root / "jobs/SMOKE_JOB_DESCRIPTION.md").exists())
        manifest = json.loads((self.root / MANIFEST_PATH).read_text())
        self.assertEqual(manifest["schema"], SCHEMA_VERSION)

    def _make_legacy_fixture(self):
        legacy_root = Path(self.temp.name) / "legacy-workspace"
        legacy_root.mkdir()
        hashes = {}
        for old_path, new_path in LEGACY_TO_CURRENT.items():
            dest = legacy_root / old_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(FIXTURES[new_path], encoding="utf-8")
            hashes[str(old_path)] = hashlib.sha256(dest.read_bytes()).hexdigest()
        manifest = {
            "schema": 1,
            "purpose": "Synthetic smoke-test baseline; all data fictional",
            "files": hashes,
            "candidate_files": sorted(
                str(p.relative_to(legacy_root))
                for p in (legacy_root / "candidate").rglob("*") if p.is_file()
            ),
            "approved_output": str(APPROVED_OUTPUT),
        }
        path = legacy_root / MANIFEST_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(manifest, indent=2, sort_keys=True))
        return legacy_root

    def test_legacy_fixture_migrates_without_overwriting(self):
        old_root = self._make_legacy_fixture()
        created = migrate(old_root)
        self.assertEqual(len(created), 2)
        self.assertTrue((old_root / BACKUP_MANIFEST_PATH).exists())
        self.assertEqual(check(old_root, "baseline"), [])
        self.assertFalse((old_root / "jobs/SMOKE_JOB_DESCRIPTION.md").exists())
        self.assertTrue((old_root / "applications/smoke-test/SMOKE_JOB_DESCRIPTION.md").exists())
        self.assertTrue((old_root / "candidate/profile/jobs/SMOKE_EMPLOYMENT.md").exists())
        with self.assertRaises(ValueError):
            migrate(old_root)

    def test_legacy_migration_rejects_modified_candidate(self):
        old_root = self._make_legacy_fixture()
        p = old_root / "candidate/SMOKE_PROFILE.md"
        p.write_text(p.read_text() + "tampered")
        with self.assertRaises(ValueError):
            migrate(old_root)
        self.assertTrue(p.is_file())
        self.assertFalse((old_root / BACKUP_MANIFEST_PATH).exists())

    def test_legacy_migration_rejects_destination_collision(self):
        old_root = self._make_legacy_fixture()
        p = old_root / "applications/smoke-test/SMOKE_JOB_DESCRIPTION.md"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("must not replace")
        with self.assertRaises(FileExistsError):
            migrate(old_root)
        self.assertEqual(p.read_text(), "must not replace")
        self.assertTrue((old_root / "candidate/SMOKE_PROFILE.md").exists())

    def test_symlink_fixture_path_is_rejected(self):
        root = Path(self.temp.name) / "second"
        root.mkdir()
        (root / "candidate").symlink_to(self.root / "candidate", target_is_directory=True)
        with self.assertRaises(ValueError):
            initialize(root)


if __name__ == "__main__":
    unittest.main()
