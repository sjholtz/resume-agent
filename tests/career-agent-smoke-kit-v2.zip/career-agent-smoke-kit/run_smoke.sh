#!/usr/bin/env bash
# Convenient manual test driver. Requires your existing guix-agent launcher.
set -euo pipefail
APP_DIR="${RESUME_AGENT_APP:-$HOME/bin/resume-agent}"
WORKSPACE_DIR="${RESUME_AGENT_TEST_WORKSPACE:-$HOME/career-test}"
JAIL_CMD="${RESUME_AGENT_JAIL_CMD:-guix-agent}"
if (( $# == 0 )); then
  echo 'Usage: ./run_smoke.sh "prompt to send to the career agent"' >&2
  exit 2
fi
exec "$JAIL_CMD" --app "$APP_DIR" "$WORKSPACE_DIR" -- --message "$*"
