# Career Agent — Live Guix / Deep Agents Smoke-Test Kit

This kit is **not** a career-agent code patch. It creates disposable, explicitly fictional files in your already initialized `~/career-test` workspace; it does not modify `/app`, `AGENTS.md`, the Guix launcher, or real candidate files.

## First, clean up a stale memory instruction

In `agents/orchestrator/AGENTS.md`, Section 3.2, change the Orchestrator / Read Candidate Profile cell from `Through approved reads` to `Yes — no HITL required`. That is the **exact source** of the phrase repeated by Qwen in Test 2. Also check Section 8, Phase 1: `Request approval to read necessary files` is obsolete after your policy change. Both should state that reading requires no HITL.

## Preparation (host shell)

```bash
mkdir -p "$HOME/career-test/candidate"  # already done in your case
unzip career-agent-smoke-kit.zip -d "$HOME/career-smoke-kit"
cd "$HOME/career-smoke-kit"
python3 smoke_fixture.py init --root "$HOME/career-test"
python3 smoke_fixture.py check --root "$HOME/career-test" --stage baseline
python3 -m unittest discover -s tests -v
```

`init` **refuses to overwrite** any fixture files and an existing `SMOKE_RESULT.md`. Its files all have `SMOKE_` names (except the manifest) to make them readily identifiable. It may be run only once in a workspace. Use an empty/disposable career workspace; do not run it against a real candidate repository.

The fictional candidate profile is deliberately under `/workspace/candidate` because that is the default protected profile prefix in the prior `permissions.py`. If your installed profile prefix differs, adjust or confirm `RESUME_AGENT_PROFILE_PREFIX` in your career-agent application configuration *before* testing. Do not change the generic Guix launcher.

Run prompts with:

```bash
./run_smoke.sh "$(cat prompts/04a-read-workspace.txt)"
```

The wrapper invokes `guix-agent --app ~/bin/resume-agent ~/career-test -- --message ...`. Customize `RESUME_AGENT_APP`, `RESUME_AGENT_TEST_WORKSPACE`, and `RESUME_AGENT_JAIL_CMD` if necessary. For tracing tests, use the explicit Guix command in the test plan instead of this wrapper.

## Sequence

Follow [`TEST_PLAN.md`](TEST_PLAN.md). Keep a terminal log, note *whether a tool was actually attempted*, and run `smoke_fixture.py check --stage ...` after each stage. One-shot `--message` runs have a fresh in-memory checkpoint; **the workspace files persist**, which is why test order matters.

## Interpretation of a pass

- **Filesystem pass**: fixture hashes, expected marker, and candidate-directory inventory match the current stage.
- **Behavioral pass**: the model delegates correctly, refuses unauthorized work, and reports honestly.
- **Runtime-enforcement pass**: you observe the actual tool call denied or interrupted by Deep Agents; a model's refusal alone is *not* enough to establish this.

The fixture checker can demonstrate the first category, **not** the other two. Keep actual interrupt/denial evidence from the CLI/trace. The included offline unit tests exercise this checker, not Deep Agents itself.

The review and profile-denial tests may be refused by the model before any tool is called. In that case record **behavioral pass / enforcement not exercised** and use a deterministic real-tool integration test later; do not weaken instructions to force a prohibited edit.

## Important privacy/security details

- `--trace` can send the test run to LangSmith; use only this synthetic fixture when experimenting with tracing.
- Do not print or export real candidate information into logs or test artifacts.
- Always choose **No** on the first rejected test's HITL dialog. No approval is implicit.
- Never interpret “model said it wrote” as proof; check the filesystem.
- No fixtures or test scripts should be copied into authoritative profile folders other than the synthetic `SMOKE_` files created here.
