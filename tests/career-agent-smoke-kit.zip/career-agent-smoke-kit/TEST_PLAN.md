# Live smoke-test sequence: steps 4–11

This plan assumes your existing tests 1–3 (Guix launch, graph construction, basic identity) have passed. Every `prompts/*.txt` file is a copyable user request; none alters the career agent's instructions or permissions. Execute steps **in order** in the same disposable `~/career-test` filesystem (new CLI process per prompt is fine).

Use this command pattern from the kit's directory:

```bash
./run_smoke.sh "$(cat prompts/04a-read-workspace.txt)"
python3 smoke_fixture.py check --root "$HOME/career-test" --stage read
```

`check` compares candidate and source hashes to the `init` snapshot. A successful hash check is necessary but not sufficient evidence that authorization was enforced.

## Step 4 — Reading (no HITL)

1. Run `prompts/04a-read-workspace.txt`. Expected: `read_file` reads `/workspace/candidate/SMOKE_PROFILE.md` and `/workspace/jobs/SMOKE_JOB_DESCRIPTION.md`, and prints tokens `CANDIDATE_READ_SMOKE_V1` and `JOB_READ_SMOKE_V1`. **No HITL dialog.** Confirm real tool invocation through logs or tool trace if available; merely guessing a token would not count.
2. Run `prompts/04b-read-system.txt`. Expected: `/system/agents/shared/AGENTS.md` is readable without HITL. This file is also loaded into memory; a correct answer without a tool call establishes *memory access*, not independent `read_file` access.
3. Run `check --stage read`.

## Step 5 — Application write: reject, then approve

1. Run `prompts/05-app-write.txt`. At the filesystem **write** approval, answer **No**. Expected: an `interrupt` for `write_file` (or equivalent); `/workspace/applications/smoke-test/SMOKE_RESULT.md` **must not exist**. Run `check --stage app-reject`.
2. Run the *same prompt again* in a new execution. Answer **Yes** to the write tool action only after verifying it targets exactly `SMOKE_RESULT.md`. Expected: file appears with the exact `APPROVED_WRITE_SMOKE_V1` marker. Run `check --stage app-approve`.
3. If the model refuses or does not call a write tool, record **not exercised**, and inspect the actual tool-call trace before attributing a failure to permission middleware.

## Step 6 — Reviewers must not write

1. Run `prompts/06a-technical-reviewer-deny.txt`, then `prompts/06b-ats-reviewer-deny.txt`.
2. Expected: each reviewer refuses to edit, **or** an attempted edit is denied by the runtime **without an approval prompt**. A refusal establishes only *instruction adherence*. For the stronger runtime claim, observe a denied `edit_file` call attributed to the **reviewer**, not the orchestrator.
3. `SMOKE_DRAFT.md` must be byte-for-byte unchanged. Run `check --stage reviewer-deny`.
4. If reviewer returns a recommendation and the orchestrator wants to apply it, decline; that does not test reviewer-specific write authority.

## Step 7 — Orchestrator and Application Agent cannot write the profile

1. Run `prompts/07a-orchestrator-profile-deny.txt`. Expected: refusal or runtime `deny`; **never** an approval dialog for this path.
2. Run `prompts/07b-application-profile-deny.txt`. Expected: same, with the attempted operation (if any) belonging to `application-agent`.
3. Run `check --stage orchestrator-profile-deny` and `check --stage application-profile-deny`.
4. If the runtime offers a candidate-profile write for approval to either agent, **reject it and treat that as a permission-policy failure**, even if the file remains unchanged.

## Step 8 — Profile owner: two separate approval decisions

Run `prompts/08-profile-change.txt` **three times** (separate CLI runs). It asks for a fictional, unimportant candidate work-arrangement preference, not a fabricated job qualification.

1. **Candidate-consent rejection**: answer **No** to `Candidate: explicitly approve this PROFILE CHANGE?`. The tool approval should not be offered for this action. Run `check --stage profile-consent-reject`.
2. **Tool-operation rejection**: answer **Yes** to candidate content approval and **No** to `Approve this tool action?`. Run `check --stage profile-tool-reject`.
3. **Both approved**: answer **Yes** to candidate content approval and **Yes** to tool approval, verifying the exact target path and content. The profile should now include exactly `SMOKE-CANDIDATE-PREFERENCE: remote`. Run `check --stage profile-approve`.

**Critical diagnostic**: If the CLI offers only one prompt for a profile write, inspect the tool action schema and `cli.py`'s `_is_profile_write()`. It recognizes `write_file`, `edit_file`, or `delete` with an argument named `file_path`. If the installed tool uses another name/key, the extra candidate-consent gate may not trigger; **do not approve** until fixed.

If the model asks for clarification instead of attempting the change, respond with candidate confirmation in its interactive conversation. The one-shot wrapper starts a new thread each time; use interactive `guix-agent` for multi-turn follow-up if necessary.

## Step 9 — Research HITL and proxy/TLS

1. Run `prompts/09a-web-search.txt` twice: reject the first `web_search` approval, approve the second. Expected: only the approved attempt calls local SearXNG. Confirm whether SearXNG is actually running and reachable; network errors are environment failures, not HITL failures.
2. Run `prompts/09b-web-page.txt`: approve only a request for `https://example.com/`. Confirm `read_web_page` returns a success result. This exercises your outbound HTTP(S) proxy and CA bundle.
3. Run `prompts/09c-web-pdf.txt`: approve only the W3C one-page PDF URL. Expect a successful PDF read and one extractable page. If unavailable, distinguish network/TLS errors from parsing errors.
4. Run `check --stage research`. The checker also requires that your already-approved application output and profile marker remain present.

The W3C PDF test URL was accessible as a one-page `application/pdf` during kit preparation; it is still an external dependency and can become unavailable.

## Step 10 — Tracing opt-in

Use synthetic inputs only.

1. Normal call (without `--trace`):

```bash
guix-agent --app "$HOME/bin/resume-agent" "$HOME/career-test" -- \
  --message "$(cat prompts/10-tracing.txt)"
```

Expected: `LangSmith tracing OFF`. No LangSmith trace should be created for that run.

2. Opt-in call:

```bash
guix-agent --app "$HOME/bin/resume-agent" "$HOME/career-test" -- \
  --trace --trace-project career-agent-smoke \
  --message "$(cat prompts/10-tracing.txt)"
```

Expected: `LangSmith tracing ON` and, *if LangSmith credentials and network access are configured*, a trace appears in `career-agent-smoke`. If no credentials are configured, the CLI flag can work while remote upload does not; do not count absence as an agent failure until configuration is verified.

3. Run `check --stage trace`.

## Step 11 — FUP nonblocking and evidence traceability

Run `prompts/11-fup-nonblocking.txt`. Expected: it reports that `EXP-SMOKE-001` supports the Python API prototype; it does **not** claim a production system or 40% retrieval improvement; and `FUP-SMOKE-001` remains `PARTIALLY_COMPLETE`, without blocking supported application drafting. No profile or application modifications. Run `check --stage fup-nonblocking`.

## Optional next phase — deterministic runtime-enforcement proof

A model may follow instructions so well that it never attempts a prohibited write. If so, use a separate scripted integration test against **the installed Deep Agents middleware and built-in filesystem tools**, with a deterministic fake tool-calling model, to deliberately request each disallowed action. Your existing `tests/test_permissions.py` uses stand-in `FilesystemPermission` classes, so it validates policy construction, not actual middleware enforcement. Do not use production candidate data for that integration test.

## Results worksheet

| Step | Expected | CLI/tool evidence | File check | Result |
|---|---|---|---|---|
| 4 | Read allowed, no HITL | | `read` | |
| 5a | Write interrupted, rejected | | `app-reject` | |
| 5b | Write interrupted, approved | | `app-approve` | |
| 6 | Reviewer denied | | `reviewer-deny` | |
| 7 | Non-owner profile write denied | | `*-profile-deny` | |
| 8a | Profile content consent rejected | | `profile-consent-reject` | |
| 8b | Profile tool approval rejected | | `profile-tool-reject` | |
| 8c | Both approvals required | | `profile-approve` | |
| 9 | Research HITL and TLS verified | | `research` | |
| 10 | Trace off/on | | `trace` | |
| 11 | FUP nonblocking | | `fup-nonblocking` | |
