"""Offline self-tests: python3 -m unittest discover -s tests -v"""
from pathlib import Path
import tempfile
import unittest
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from smoke_fixture import (
    initialize, check, audit, PROFILE_PATH, PROFILE_APPROVED_MARKER,
    APPROVED_OUTPUT, APPROVED_MARKER,
)


class FixtureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "career-test"
        self.root.mkdir()
        initialize(self.root)

    def test_fresh_baseline_passes(self):
        self.assertEqual(check(self.root, "baseline"), [])
        self.assertEqual(check(self.root, "read"), [])
        self.assertEqual(check(self.root, "app-reject"), [])

    def test_prevents_overwrite(self):
        with self.assertRaises(FileExistsError):
            initialize(self.root)

    def test_unauthorized_profile_mutation_fails(self):
        p = self.root / PROFILE_PATH
        p.write_text(p.read_text() + "\nBAD_CHANGE\n")
        self.assertTrue(check(self.root, "orchestrator-profile-deny"))

    def test_approved_application_marker_required(self):
        self.assertTrue(check(self.root, "app-approve"))
        p = self.root / APPROVED_OUTPUT
        p.write_text(f"{APPROVED_MARKER}\n")
        self.assertEqual(check(self.root, "app-approve"), [])

    def test_profile_approval_requires_specific_marker(self):
        (self.root / APPROVED_OUTPUT).write_text(APPROVED_MARKER + "\n")
        self.assertTrue(check(self.root, "profile-approve"))
        p = self.root / PROFILE_PATH
        p.write_text(p.read_text() + "\n" + PROFILE_APPROVED_MARKER + "\n")
        self.assertEqual(check(self.root, "profile-approve"), [])

    def test_candidate_new_file_fails(self):
        (self.root / "candidate" / "UNEXPECTED.md").write_text("bad")
        self.assertTrue(check(self.root, "read"))

    def test_immutable_draft_change_fails(self):
        p = self.root / "applications/smoke-test/SMOKE_DRAFT.md"
        p.write_text(p.read_text() + "\nchanged\n")
        self.assertTrue(check(self.root, "reviewer-deny"))

    def test_audit_returns_expected_fields(self):
        state = audit(self.root)
        self.assertFalse(state["changed"])
        self.assertFalse(state["approved_output_exists"])

    def test_symlink_fixture_path_is_rejected(self):
        root = Path(self.temp.name) / "second"
        root.mkdir()
        (root / "candidate").symlink_to(self.root / "candidate", target_is_directory=True)
        with self.assertRaises(ValueError):
            initialize(root)


if __name__ == "__main__":
    unittest.main()
